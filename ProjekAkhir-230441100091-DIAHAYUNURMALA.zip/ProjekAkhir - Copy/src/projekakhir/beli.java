/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projekakhir;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class beli extends javax.swing.JFrame {

    private Connection conn; // Asumsikan koneksi database sudah siap digunakan
    
    public beli() {
        initComponents();
        this.conn = conn;
        setTableColumns();
       
    }

   // Metode untuk mengatur kolom di tabel detail pemesanan
private void setTableColumns() {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID User");      // Menambahkan kolom ID User
    model.addColumn("ID Produk");     // Menambahkan kolom ID Produk
    model.addColumn("Nama Produk");   // Menambahkan kolom Nama Produk
    model.addColumn("Jumlah");        // Menambahkan kolom Jumlah
    model.addColumn("Harga");         // Menambahkan kolom Harga
    tblTransaksi.setModel(model);
}


    // Metode untuk memuat data dari database ke tabel
private void loadDataFromDatabase(int user_id) {
    DefaultTableModel model = (DefaultTableModel) tblTransaksi.getModel();
    model.setRowCount(0); // Bersihkan data lama di tabel

    // Query untuk mengambil data berdasarkan userId
    String sql = "SELECT t.id_user, t.id_produk, t.nama_produk, t.harga, t.jumlah " +
                 "FROM transaksi t " +
                 "JOIN users u ON t.user_id = u.user_id " + // Ganti 'id_user' sesuai nama kolom di tabel users
                 "WHERE t.user_id = ?"; // Filter berdasarkan id_user

    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, user_id); // Set parameter id_user

        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int idUser  = rs.getInt("id_user");
                int idProduk = rs.getInt("id_produk");
                String namaProduk = rs.getString("nama_produk");
                double harga = rs.getDouble("harga");
                int jumlah = rs.getInt("jumlah");
                model.addRow(new Object[]{idUser , idProduk, namaProduk, harga, jumlah});
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Gagal memuat data: " + e.getMessage());
    }
}
    // Tambahkan produk yang dibeli ke tabel
private void addProductToTable(int idUser , int idProduk, String namaProduk, int jumlah, double harga) {
    DefaultTableModel model = (DefaultTableModel) tblTransaksi.getModel();
    model.addRow(new Object[]{idUser , idProduk, namaProduk, jumlah, harga});
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        tfAlamat = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTransaksi = new javax.swing.JTable();
        cbMetodePembayaran = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        tfnama = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tfharga = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Detail Pemesanan");

        jLabel4.setText("Metode Pembayaran :");

        jLabel5.setText("Alamat :");

        jButton1.setText("beli Sekarang");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        tblTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblTransaksi);

        cbMetodePembayaran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Transfer (BRI/BCA/Mandiri/BTN)", "Dana", "SeaBank" }));

        jLabel2.setText("Nama :");

        jLabel3.setText("jLabel3");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(60, 60, 60))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(190, 190, 190))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 464, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel3)
                        .addComponent(jLabel2)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tfAlamat)
                            .addComponent(cbMetodePembayaran, 0, 230, Short.MAX_VALUE)
                            .addComponent(tfnama)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(tfharga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfharga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tfnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tfAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbMetodePembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addComponent(jButton1)
                .addContainerGap(72, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
//        // Contoh data produk yang diambil dari text field atau sumber lainnya
//        String namaProduk = "Nama Produk Contoh";
//        int jumlah = Integer.parseInt(tfjumlah.getText()); // TextField untuk jumlah pembelian
//        double harga = 100000.0; // Harga produk contoh
//
//        // Tambahkan data ke tabel detail pemesanan
//        addProductToTable(namaProduk, jumlah, harga);                                       
    // Ambil alamat dan metode pembayaran
    String alamat = tfAlamat.getText();
    String metodePembayaran = cbMetodePembayaran.getSelectedItem().toString();

    // Cek jika alamat tidak kosong
    if (alamat.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Alamat harus diisi!");
        return;
    }

    // Simpan detail pemesanan ke tabel pemesanan dan order_item
    try {
        // 1. Simpan data pemesanan utama ke tabel pemesanan (contoh tabel pemesanan)
        String insertPemesananSQL = "INSERT INTO pemesanan (alamat, metode_pembayaran) VALUES (?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertPemesananSQL, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, alamat);
            pstmt.setString(2, metodePembayaran);
            pstmt.executeUpdate();

            // Ambil ID pemesanan yang baru saja disimpan
            ResultSet rs = pstmt.getGeneratedKeys();
            int idPemesanan = 0;
            if (rs.next()) {
                idPemesanan = rs.getInt(1);
            }

            // 2. Simpan setiap produk yang dipilih ke tabel order_item
            DefaultTableModel model = (DefaultTableModel) tblTransaksi.getModel();
            for (int row = 0; row < model.getRowCount(); row++) {
                String namaProduk = (String) model.getValueAt(row, 0);
                int jumlah = (int) model.getValueAt(row, 1);
                double harga = (double) model.getValueAt(row, 2);
                double totalHarga = jumlah * harga;

                String insertOrderItemSQL = "INSERT INTO transaksi (id_pemesanan, nama_produk, jumlah, harga, total_harga) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(insertOrderItemSQL)) {
                    stmt.setInt(1, idPemesanan);
                    stmt.setString(2, namaProduk);
                    stmt.setInt(3, jumlah);
                    stmt.setDouble(4, harga);
                    stmt.setDouble(5, totalHarga);
                    stmt.executeUpdate();
                }
            }

            // 3. Tampilkan pesan sukses dan reset form jika perlu
            JOptionPane.showMessageDialog(this, "Pemesanan berhasil!");
            this.dispose();  // Tutup frame beli setelah pemesanan berhasil
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage());
    }

    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new beli().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbMetodePembayaran;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblTransaksi;
    private javax.swing.JTextField tfAlamat;
    private javax.swing.JTextField tfharga;
    private javax.swing.JTextField tfnama;
    // End of variables declaration//GEN-END:variables
}
